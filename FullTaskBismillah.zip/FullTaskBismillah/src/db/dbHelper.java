/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package db;

/**
 *
 * @author acer
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
public class dbHelper {
    
    //tabel Tim
    
    
    
    
    //tabel Anggota tim
//    private static final int IdAnggotaTim = "root";
//    private static final String namaAnggota = "root";
//    private static final String peranAnggota = "root";
//    private static final String kontakAnggota = "root";
//    
//    //tabel proyek
//    private static final String IDProyek = "root";
//    private static final String namaProyek = "root";
//    private static final String tujuanProyek = "root";
//    private static final String tenggatWaktu = "root";
//    private static final String Anggaran= "root";
//    private static final String statusProyek = "root";
//    
    //tabel signin signup
    private static final String Nama = "root";
    private static final String Username = "root";
    private static final String Password = "";
    private static final String db = "fulltask";
    private static final String MYCONN = "jdbc:mysql://localhost/"+db;
 
    public static Connection getConnection(){
    Connection conn = null;
 
    try {
        conn = DriverManager.getConnection(MYCONN, Username, Password);
        System.out.println("Koneksi Berhasil");
    } catch (SQLException ex) {
        Logger.getLogger(dbHelper.class.getName()).log(Level.SEVERE, null, ex);
        System.out.println("Koneksi Gagal");
 }
 
 return conn;
 }
}

    

