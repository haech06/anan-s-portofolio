/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package fulltaskbismillah;

import com.mycompany.fulltaskbismillah.AnggotaTim;
import db.dbHelper;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;

import javafx.scene.control.Hyperlink;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author acer
 */
public class LoginController implements Initializable {
    
    

    @FXML
    private Button btnLogin;

    @FXML
    private PasswordField fldPass;

    @FXML
    private TextField fldUsn;

    @FXML
    private Hyperlink hpDaftar;

    @FXML
    private Hyperlink hpLupaPw;

    @FXML
    void goToTabDaftar(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Daftar.fxml"));

        Stage stage = (Stage) hpDaftar.getScene().getWindow();
        stage.setScene(new Scene(root));

    }

    @FXML
    void goToTabLupaPw(ActionEvent event) {

    }

    @FXML
    void goToTabMenu(ActionEvent event) throws IOException {
        
        String username = fldUsn.getText();
        String password = fldPass.getText();

        if (validasiLogin(username, password)) {
            showInfoDialog(username, "Welcome to FullTask! Have a nice day!");
            

            buatUsn.setUsername(username);

            FXMLLoader loader = new FXMLLoader(getClass().getResource("menuUtama.fxml"));
            Parent root = loader.load();


            Stage stage = (Stage) btnLogin.getScene().getWindow();
            stage.setScene(new Scene(root));
        } else {
            showErrorDialog("Login Gagal", "Username atau password salah. Silakan coba lagi.");
        }
    
        

    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    
        // TODO
    }    
    
       public ObservableList<AnggotaTim> getNama(){
        ObservableList<AnggotaTim> atim = FXCollections.observableArrayList();
        Connection connection = dbHelper.getConnection();
        String query = "SELECT * FROM `signup`";
        Statement st;
        ResultSet rs;
        
        try{
            if (connection != null){
            st = connection.createStatement();
            rs = st.executeQuery(query);
            AnggotaTim temp;
            while (rs.next()){
                temp = new AnggotaTim(rs.getString("Nama"), rs.getString("Username"), rs.getString("Password"));
                atim.add(temp);
            }
            } else {
                System.out.println("Koneksi ke database gagal.");
            }
        } catch (SQLException ex){
            ex.printStackTrace();
        }
        
        return atim;
        
    }

    
    public ObservableList<AnggotaTim> getUsername(){
        ObservableList<AnggotaTim> atim = FXCollections.observableArrayList();
        Connection connection = dbHelper.getConnection();
        String query = "SELECT * FROM `signin`";
        Statement st;
        ResultSet rs;
        
        try{
            if (connection != null){
            st = connection.createStatement();
            rs = st.executeQuery(query);
            AnggotaTim temp;
            while (rs.next()){
                temp = new AnggotaTim(rs.getString("Username"), rs.getString("Password"));
                atim.add(temp);
            }
            } else {
                System.out.println("Koneksi ke database gagal.");
            }
        } catch (SQLException ex){
            ex.printStackTrace();
        }
        
        return atim;
        
    }

    
    private boolean validasiLogin(String username, String password) {
    ObservableList<AnggotaTim> atimSignUp = getNama();
    ObservableList<AnggotaTim> atimSignIn = getUsername();

    // Validasi login menggunakan tabel signup
    if (atimSignUp != null) {
        for (AnggotaTim anggota : atimSignUp) {
            if (anggota != null && anggota.getUsername() != null && anggota.getPassword() != null) {
                if (anggota.getUsername().equals(username) && anggota.getPassword().equals(password)) {
                    return true; // login berhasil
                }
            }
        }
    }

    // Validasi login menggunakan tabel signin
    if (atimSignIn != null) {
        for (AnggotaTim anggota : atimSignIn) {
            if (anggota != null && anggota.getUsername() != null && anggota.getPassword() != null) {
                if (anggota.getUsername().equals(username) && anggota.getPassword().equals(password)) {
                    return true; // login berhasil
                }
            }
        }
    }

    return false; // login gagal
}



      private void showInfoDialog(String username, String content) {
      Alert alert = new Alert(Alert.AlertType.INFORMATION);
      alert.setHeaderText("LOGIN BERHASIL");
      alert.setContentText("Welcome to FullTask! Have a nice day, " + username + "!");
      alert.showAndWait();
}

    private void showErrorDialog(String title, String content) {
    Alert alert = new Alert(Alert.AlertType.ERROR);
    alert.setTitle(title);
    alert.setHeaderText("KESALAHAN");
    alert.setContentText("Username atau password salah. Silakan coba lagi.");
    alert.showAndWait();
}

}

    
   
    

