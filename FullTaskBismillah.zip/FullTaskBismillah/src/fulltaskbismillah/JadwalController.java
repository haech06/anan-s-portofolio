/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package fulltaskbismillah;


import db.dbHelper;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author acer
 */
public class JadwalController implements Initializable {

    @FXML
    private Button btnSearch;

    @FXML
    private Hyperlink hpDashboard;

    @FXML
    private Hyperlink hpTambahJadwal;

    @FXML
    private TableColumn<Jadwal, Integer> klmIdJadwal;

    @FXML
    private TableColumn<Proyek, Integer> klmIdProyek;

    @FXML
    private TableColumn<Tugas, Integer> klmDeskripsiTugas;

    @FXML
    private TableColumn<Status, String> klmStatus;

    @FXML
    private TableColumn<Jadwal, LocalDate> klmWaktuMulai;

    @FXML
    private TableColumn<Jadwal, LocalDate> klmWaktuSelesai;

    @FXML
    private TableView<Jadwal> tblJadwal;

    @FXML
    void goToTabMenuUtama(ActionEvent event) throws IOException {
        
    FXMLLoader loader = new FXMLLoader(getClass().getResource("menuUtama.fxml"));
    Parent root = loader.load();
    Scene scene = new Scene(root);
    Stage stage = (Stage) hpDashboard.getScene().getWindow(); // Mendapatkan Stage untuk window saat ini
    stage.setScene(scene);       
        

    }
    
    public ObservableList<Jadwal> getIdJadwal() {
    ObservableList<Jadwal> jadwal = FXCollections.observableArrayList();
    Connection connection = dbHelper.getConnection();
    String query = "SELECT j.idJadwal, p.IDProyek, t.deskripsiTugas, j.waktuMulai, j.waktuSelesai, s.jenisStatus " +
                   "FROM jadwal j " +
                   "JOIN status s ON j.idStatus = s.idStatus " +
                   "JOIN tugas t ON j.idTugas = t.idTugas " +
                   "JOIN proyek p ON j.IDProyek = p.IDProyek";

    try (Statement st = connection.createStatement();
         ResultSet rs = st.executeQuery(query)) {

       while (rs.next()) {
        Jadwal temp = new Jadwal(
        rs.getInt("idJadwal"),
        new Proyek(rs.getInt("IDProyek")),
        new Tugas(rs.getString("deskripsiTugas")),
        rs.getDate("waktuMulai").toLocalDate(),
        rs.getDate("waktuSelesai").toLocalDate(),
        new Status(rs.getString("jenisStatus"))
    );
    jadwal.add(temp);
       }
    } catch (SQLException ex) {
        ex.printStackTrace();
    } finally {
        try {
            if (connection != null) {
                connection.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    return jadwal;
}
    
    public void showDaftarJadwal(){
        ObservableList<Jadwal> list = getIdJadwal();
        
        klmIdJadwal.setCellValueFactory(new PropertyValueFactory<>("IdJadwal"));
        klmIdProyek.setCellValueFactory(new PropertyValueFactory<>("proyek"));
        klmDeskripsiTugas.setCellValueFactory(new PropertyValueFactory<>("tugas"));
        klmWaktuMulai.setCellValueFactory(new PropertyValueFactory<>("waktuMulai"));
        klmWaktuSelesai.setCellValueFactory(new PropertyValueFactory<>("waktuSelesai"));
        klmStatus.setCellValueFactory(new PropertyValueFactory<>("status"));
        tblJadwal.setItems(list);
        
    }



    @FXML
    void goToTabTambahJadwal(ActionEvent event) throws IOException {
        
    FXMLLoader loader = new FXMLLoader(getClass().getResource("tambahJadwal.fxml"));
    Parent root = loader.load();
    Scene scene = new Scene(root);
    Stage stage = (Stage) hpTambahJadwal.getScene().getWindow(); // Mendapatkan Stage untuk window saat ini
    stage.setScene(scene);      

    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        showDaftarJadwal();
    }    
    
}
