/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package fulltaskbismillah;

import com.mycompany.fulltaskbismillah.AnggotaTim;
import db.dbHelper;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author acer
 */
public class TimController implements Initializable {

     @FXML
    private Button btnSearch;

    @FXML
    private Hyperlink hpDaftarTim;

    @FXML
    private Hyperlink hpDashboard;

    @FXML
    private Hyperlink hpTambahTim;

    @FXML
    private TableColumn<Tim, String> klmINamaProyek;

    @FXML
    private TableColumn<Tim, Integer> klmIdTim;

    @FXML
    private TableColumn<Tim, String> klmNamaTim;

    @FXML
    private TableColumn<Tim, String> klmDescTim;

    @FXML
    private TableView<Tim> tblTim;

    @FXML
    void goToTabMenuUtama(ActionEvent event) throws IOException {
    FXMLLoader loader = new FXMLLoader(getClass().getResource("menuUtama.fxml"));
    Parent root = loader.load();
    Scene scene = new Scene(root);
    Stage stage = (Stage) hpDashboard.getScene().getWindow(); // Mendapatkan Stage untuk window saat ini
    stage.setScene(scene);

    }

    @FXML
    void goToTabTambahTim(ActionEvent event) throws IOException {
    FXMLLoader loader = new FXMLLoader(getClass().getResource("tambahTim.fxml"));
    Parent root = loader.load();
    Scene scene = new Scene(root);
    Stage stage = (Stage) hpTambahTim.getScene().getWindow(); // Mendapatkan Stage untuk window saat ini
    stage.setScene(scene);

    }
    
    
   public ObservableList<Tim> getIdTim(){
    ObservableList<Tim> tim = FXCollections.observableArrayList();
    Connection connection = dbHelper.getConnection();
    String query = "SELECT t.IdTim, t.namaTim, t.deskripsiTim, p.namaProyek " +
                   "FROM tim t " +
                   "JOIN proyek p ON t.IDProyek = p.IDProyek";
    Statement st;
    ResultSet rs;
    
   
           try{
        if (connection != null){
            st = connection.createStatement();
            rs = st.executeQuery(query);
            Tim temp;
            while (rs.next()){
                temp = new Tim(
                    rs.getInt("idTim"),
                    rs.getString("namaTim"),
                    rs.getString("deskripsiTim"),
                    new Proyek(rs.getString("namaProyek"))
                );
                tim.add(temp);
            }
        } else {
            System.out.println("Koneksi ke database gagal.");
        }
    } catch (SQLException ex){
        ex.printStackTrace();
    }
    return tim;
}

        
    
    
    public void showDaftarTim(){
        ObservableList<Tim> list = getIdTim();
        
        klmIdTim.setCellValueFactory(new PropertyValueFactory<>("idTim"));
        klmNamaTim.setCellValueFactory(new PropertyValueFactory<>("namaTim"));
        klmDescTim.setCellValueFactory(new PropertyValueFactory<>("deskripsiTim"));
        klmINamaProyek.setCellValueFactory(new PropertyValueFactory<>("proyek"));
        tblTim.setItems(list);
    }


    @Override
    public void initialize(URL url, ResourceBundle rb) {
       showDaftarTim();
    }    
    
}
