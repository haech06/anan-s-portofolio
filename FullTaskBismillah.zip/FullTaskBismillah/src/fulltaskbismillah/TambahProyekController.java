/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package fulltaskbismillah;

import db.dbHelper;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author acer
 */
public class TambahProyekController implements Initializable {
    
    @FXML
    private Button btnTambahData;
    
    @FXML
    private TextField fldAnggaran;

    @FXML
    private TextField fldIDProyek;

    @FXML
    private TextField fldNamaProyek;

    
    @FXML
    private TextField fldStatusProyek;

    @FXML
    private DatePicker fldTenggat;

    @FXML
    private TextField fldTujuanProyek;


    @FXML
    private Hyperlink hpDaftarProyek;

    @FXML
    private Hyperlink hpDashboard;
    
    @FXML
    private Hyperlink hpTambahProyek;
    
    
    @FXML
    void dataBertambah(ActionEvent event) throws IOException {
        if(event.getSource() == btnTambahData){
        tambahData();
        showInfoDialog("Berhasil menambahkan data");
    }
    
    }
    @FXML
    void goToTabTambahProyek(ActionEvent event) {

    }

    @FXML
    void goToTabDaftarProyek(ActionEvent event) throws IOException {
        
    FXMLLoader loader = new FXMLLoader(getClass().getResource("proyek.fxml"));
    Parent root = loader.load();
    Scene scene = new Scene(root);
    Stage stage = (Stage) hpDaftarProyek.getScene().getWindow(); // Mendapatkan Stage untuk window saat ini
    stage.setScene(scene);

    }

    @FXML
    void goToTabMenuUtama(ActionEvent event) throws IOException {
  
    FXMLLoader loader = new FXMLLoader(getClass().getResource("menuUtama.fxml"));
    Parent root = loader.load();
    Scene scene = new Scene(root);
    Stage stage = (Stage) hpDashboard.getScene().getWindow(); // Mendapatkan Stage untuk window saat ini
    stage.setScene(scene);

    }
    
     private void update(String query){
        Connection conn = dbHelper.getConnection();
        Statement st;
        ResultSet rs;
        
        try{
            st = conn.createStatement();
            st.executeUpdate(query);
        }catch(SQLException ex){
            ex.printStackTrace();
        }
    }
    
  
    
    private void tambahData() {
    try {
        Connection conn = dbHelper.getConnection();
        String query = "INSERT INTO proyek (IDProyek, namaProyek, tujuanProyek, tenggatWaktu, Anggaran, idStatus) VALUES (?, ?, ?, ? , ?, ?)";
        java.sql.PreparedStatement pst = conn.prepareStatement(query);
        
        pst.setInt(1, Integer.parseInt(fldIDProyek.getText()));
        pst.setString(2, fldNamaProyek.getText());
        pst.setString(3, fldTujuanProyek.getText());
        pst.setDate(4, java.sql.Date.valueOf(fldTenggat.getValue()));
        pst.setDouble(5, Double.parseDouble(fldAnggaran.getText()));
        pst.setInt(6, Integer.parseInt(fldStatusProyek.getText()));
        
        pst.executeUpdate();

        pst.close();
        conn.close();
        
        
    }
    catch (SQLException ex) {
        ex.printStackTrace();
    }
    
        
      
}
    
      private void showInfoDialog(String content) {
      Alert alert = new Alert(Alert.AlertType.INFORMATION);
      alert.setHeaderText("BERHASIL");
      alert.setContentText("Berhasil menambahkan data");
      alert.showAndWait();

      }


    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        fldTenggat.setValue(LocalDate.now());
        // TODO
    }    
    
}

