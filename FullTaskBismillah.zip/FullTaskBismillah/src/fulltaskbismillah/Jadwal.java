/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fulltaskbismillah;
import java.time.LocalDate;
/**
 *
 * @author acer
 */
public class Jadwal {
    private int IdJadwal;
    private Proyek proyek;
    private Tugas tugas;
    private LocalDate waktuMulai;
    private LocalDate waktuSelesai;
    private Status status;
    
    
    public Jadwal(int IdJadwal, Proyek proyek, Tugas tugas, LocalDate waktuMulai, LocalDate waktuSelesai, Status status) {
        this.IdJadwal = IdJadwal;
        this.proyek = proyek;
        this.tugas = tugas;
        this.waktuMulai = waktuMulai;
        this.waktuSelesai = waktuSelesai;
        this.status = status;
    }

    public Jadwal(Proyek proyek) {
        this.proyek = proyek;
    }


    public Jadwal(Status status) {
        this.status = status;
    }
    
    public void setStatus(Status status) {
        this.status = status;
    }

    public Status getStatus() {
        return status;
    }
     

    public void setIdJadwal(int IdJadwal) {
        this.IdJadwal = IdJadwal;
    }

    public void setProyek(Proyek proyek) {
        this.proyek = proyek;
    }

    public void setTugas(Tugas tugas) {
        this.tugas = tugas;
    }

    public void setWaktuMulai(LocalDate waktuMulai) {
        this.waktuMulai = waktuMulai;
    }

    public void setWaktuSelesai(LocalDate waktuSelesai) {
        this.waktuSelesai = waktuSelesai;
    }

    public int getIdJadwal() {
        return IdJadwal;
    }
    
    

    public Proyek getProyek() {
        return proyek;
    }

    public Tugas getTugas() {
        return tugas;
    }

    public LocalDate getWaktuMulai() {
        return waktuMulai;
    }

    public LocalDate getWaktuSelesai() {
        return waktuSelesai;
    }
       
}
