/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package fulltaskbismillah;

import com.mycompany.fulltaskbismillah.AnggotaTim;
import db.dbHelper;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author acer
 */
public class AnggotaTimController implements Initializable {

    @FXML
    private Button btnSearch;
    
    
    @FXML
    private Hyperlink hpDashboard;

    @FXML
    private Hyperlink hpHapusAnggota;

    @FXML
    private Hyperlink hpTambahAnggota;
    
    
    @FXML
    private TableColumn<AnggotaTim, Integer> klmIdAnggota;

    @FXML
    private TableColumn<AnggotaTim, String> klmKontak;

    @FXML
    private TableColumn<AnggotaTim, String> klmNamaAnggota;

    @FXML
    private TableColumn<AnggotaTim, String> klmPeran;
    
    @FXML
    private TableColumn<Tim, Integer> klmIdTim;

    @FXML
    private TableView<AnggotaTim> tblAnggota;
    
    @FXML
    void goToTabTambahAnggota(ActionEvent event) throws IOException {
    FXMLLoader loader = new FXMLLoader(getClass().getResource("tambahAnggota.fxml"));
    Parent root = loader.load();
    Scene scene = new Scene(root);
    Stage stage = (Stage) hpTambahAnggota.getScene().getWindow(); // Mendapatkan Stage untuk window saat ini
    stage.setScene(scene);
     

    }
    
     public ObservableList<AnggotaTim> getIdAnggotaTim(){
        ObservableList<AnggotaTim> anggota = FXCollections.observableArrayList();
        Connection connection = dbHelper.getConnection();
        String query = "SELECT t.idTim, a.idAnggotaTim, a.namaAnggota, a.peranAnggota,  a.kontakAnggota " +
                        "FROM tim t JOIN anggota a ON t.idTim = a.idTim";
        Statement st;
        ResultSet rs;
        
        try{
            if (connection != null){
            st = connection.createStatement();
            rs = st.executeQuery(query);
            AnggotaTim temp;
            while (rs.next()){
            temp = new AnggotaTim(
            new Tim (rs.getInt("idTim")),
            rs.getInt("IdAnggotaTim"),        
            rs.getString("namaAnggota"),
            rs.getString("peranAnggota"),
            rs.getString("kontakAnggota")
            
        );
            anggota.add(temp);

  
            }
            } else {
                System.out.println("Koneksi ke database gagal.");
            }
        } catch (SQLException ex){
            ex.printStackTrace();
        }
        
        return anggota;
        
    }
    
    public void showDaftarAnggota(){
        ObservableList<AnggotaTim> list = getIdAnggotaTim();
        klmIdTim.setCellValueFactory(new PropertyValueFactory<>("tim"));
        klmIdAnggota.setCellValueFactory(new PropertyValueFactory<>("IdAnggotaTim"));
        klmNamaAnggota.setCellValueFactory(new PropertyValueFactory<>("namaAnggota"));
        klmPeran.setCellValueFactory(new PropertyValueFactory<>("peranAnggota"));
        klmKontak.setCellValueFactory(new PropertyValueFactory<>("kontakAnggota"));
        tblAnggota.setItems(list);
    }


    @FXML
   void goToTabHapusAnggota(ActionEvent event) {
       AnggotaTim selectedAnggota = tblAnggota.getSelectionModel().getSelectedItem();

    if (selectedAnggota != null) {
        // Perform deletion logic
        if (deleteAnggota(selectedAnggota)) {
            // Refresh the TableView after successful deletion
            showDaftarAnggota();
        } else {
            System.out.println("Gagal menghapus anggota.");
        }
    } else {
        System.out.println("Hapus Gagal: Tidak ada item yang dipilih.");
    }

    }

    @FXML
    void goToTabMenuUtama(ActionEvent event) throws IOException {
    FXMLLoader loader = new FXMLLoader(getClass().getResource("menuUtama.fxml"));
    Parent root = loader.load();
    Scene scene = new Scene(root);
    Stage stage = (Stage) hpDashboard.getScene().getWindow(); // Mendapatkan Stage untuk window saat ini
    stage.setScene(scene);

    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        showDaftarAnggota();
        // TODO
    }  
   

private boolean deleteAnggota(AnggotaTim anggota) {
    Connection connection = dbHelper.getConnection();
    String query = "DELETE FROM anggota WHERE IdAnggotaTim = ?";

    try (PreparedStatement pst = connection.prepareStatement(query)) {
        pst.setInt(1, anggota.getIdAnggotaTim());
        int rowsAffected = pst.executeUpdate();
        return rowsAffected > 0;
    } catch (SQLException ex) {
        ex.printStackTrace();
        return false;
    }
}



}