/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fulltaskbismillah;
import com.mycompany.fulltaskbismillah.AnggotaTim;
import java.time.LocalDate;
/**
 *
 * @author acer
 */
public class Tugas {
    private int idTugas;
    
    private AnggotaTim anggota;
    private String deskripsiTugas;
    private LocalDate waktuMulai;
    private LocalDate waktuSelesai;
    private Status status;
    private Jadwal jadwal;

//    public Tugas(Status status, AnggotaTim anggota) {
//        this.status = status;
//        this.anggota= anggota;
//    }

    public Tugas(String deskripsiTugas) {
        this.deskripsiTugas = deskripsiTugas;
    }

    
    public Tugas(Jadwal jadwal) {
        this.jadwal = jadwal;
    }
    

   public Tugas(int idTugas, AnggotaTim anggota, String deskripsiTugas, LocalDate waktuMulai, LocalDate waktuSelesai, Status status) {
        this.idTugas = idTugas;
        this.anggota = anggota;
        this.deskripsiTugas = deskripsiTugas;
        this.waktuMulai = waktuMulai;
        this.waktuSelesai = waktuSelesai;
        this.status = status;
    }
   
    public Tugas(AnggotaTim anggota) {
        this.anggota = anggota;
    }

    public Tugas(Status status) {
        this.status = status;
    }

    public void setJadwal(Jadwal jadwal) {
        this.jadwal = jadwal;
    }
   
    public void setStatus(Status status) {
        this.status = status;
    }

    public void setAnggota(AnggotaTim anggota) {
        this.anggota = anggota;
    }
    

    public void setIdTugas(int idTugas) {
        this.idTugas = idTugas;
    }

    public void setDeskripsiTugas(String deskripsiTugas) {
        this.deskripsiTugas = deskripsiTugas;
    }


    public void setWaktuMulai(LocalDate waktuMulai) {
        this.waktuMulai = waktuMulai;
    }

    public void setWaktuSelesai(LocalDate waktuSelesai) {
        this.waktuSelesai = waktuSelesai;
    }
    

    public int getIdTugas() {
        return idTugas;
    }

    public String getDeskripsiTugas() {
        return deskripsiTugas;
    }


    public LocalDate getWaktuMulai() {
        return waktuMulai;
    }

    public LocalDate getWaktuSelesai() {
        return waktuSelesai;
    }

    public AnggotaTim getAnggota() {
        return anggota;
    }
  
    public Status getStatus() {
        return status;
    }

    public Jadwal getJadwal() {
        return jadwal;
    }

    
    public String toString(){
         return "" + deskripsiTugas;
}
    
    
   
}
