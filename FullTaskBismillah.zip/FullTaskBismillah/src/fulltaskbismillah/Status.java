/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fulltaskbismillah;

import com.mycompany.fulltaskbismillah.AnggotaTim;

/**
 *
 * @author acer
 */
public class Status {
    private int idStatus;
    private String jenisStatus;
    private Proyek proyek;
    private AnggotaTim anggota;
    private Tugas tugas;
    private Jadwal jadwal;

    public Status(Jadwal jadwal) {
        this.jadwal = jadwal;
    }

    public Status(Tugas tugas) {
        this.tugas = tugas;
    }

    public Status(Proyek proyek) {
        this.proyek = proyek;
    }

    public Status(AnggotaTim anggota) {
        this.anggota = anggota;
    }


    public Status(String jenisStatus) {
        this.jenisStatus = jenisStatus;
    }

    public Status(int idStatus, String jenisStatus) {
        this.idStatus = idStatus;
        this.jenisStatus = jenisStatus;
    }

    public void setJadwal(Jadwal jadwal) {
        this.jadwal = jadwal;
    }
    

    public void setTugas(Tugas tugas) {
        this.tugas = tugas;
    }
    
    public void setIdStatus(int idStatus) {
        this.idStatus = idStatus;
    }

    public void setJenisStatus(String jenisStatus) {
        this.jenisStatus = jenisStatus;
    }

    public int getIdStatus() {
        return idStatus;
    }

    public String getJenisStatus() {
        return jenisStatus;
    }

    public void setProyek(Proyek proyek) {
        this.proyek = proyek;
    }

    public Proyek getProyek() {
        return proyek;
    }

    public void setAnggota(AnggotaTim anggota) {
        this.anggota = anggota;
    }

    public Tugas getTugas() {
        return tugas;
    }
    
    public AnggotaTim getAnggota() {
        return anggota;
    }

    public Jadwal getJadwal() {
        return jadwal;
    }
    
    public String toString(){
    return "" + jenisStatus;
    
    
    
    
    }   
}
