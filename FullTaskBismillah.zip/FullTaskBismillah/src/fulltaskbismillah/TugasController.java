/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package fulltaskbismillah;

import com.mycompany.fulltaskbismillah.AnggotaTim;
import db.dbHelper;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author acer
 */
public class TugasController implements Initializable {

    
    @FXML
    private Button btnSearch;

    @FXML
    private Hyperlink hpDashboard;

    @FXML
    private Hyperlink hpTambahTugas;

    @FXML
    private TableColumn<AnggotaTim, String> klmAnggota;

    @FXML
    private TableColumn<Tugas, String> klmDeskripsiTugas;

    @FXML
    private TableColumn<Tugas, Integer> klmIdTugas;

    @FXML
    private TableColumn<Status, String> klmStatusTugas;

    @FXML
    private TableColumn<Tugas, LocalDate> klmWaktuMulai;

    @FXML
    private TableColumn<Tugas, LocalDate> klmWaktuSelesai;

    @FXML
    private TableView<Tugas> tblTugas;
    
    public ObservableList<Tugas> getIdTugas() {
    ObservableList<Tugas> tugas = FXCollections.observableArrayList();
    Connection connection = dbHelper.getConnection();
    String query = "SELECT t.idTugas,  a.namaAnggota, t.deskripsiTugas, t.waktuMulai, t.waktuSelesai, s.jenisStatus "
            + "FROM tugas t JOIN status s ON t.idStatus = s.idStatus JOIN anggota a ON t.idAnggotaTim = a.idAnggotaTim";

    try (Statement st = connection.createStatement();
         ResultSet rs = st.executeQuery(query)) {

       while (rs.next()) {
        Tugas temp = new Tugas(
        rs.getInt("idTugas"),
        new AnggotaTim(rs.getString("namaAnggota")), // Ganti dengan namaAnggota dari query
        rs.getString("deskripsiTugas"),
        rs.getDate("waktuMulai").toLocalDate(),
        rs.getDate("waktuSelesai").toLocalDate(),
        new Status(rs.getString("jenisStatus"))
    );
    tugas.add(temp);
       }
    } catch (SQLException ex) {
        ex.printStackTrace();
    } finally {
        try {
            if (connection != null) {
                connection.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    return tugas;
}
   

    @FXML
    void goToTabMenuUtama(ActionEvent event) throws IOException {
        
    FXMLLoader loader = new FXMLLoader(getClass().getResource("menuUtama.fxml"));
    Parent root = loader.load();
    Scene scene = new Scene(root);
    Stage stage = (Stage) hpDashboard.getScene().getWindow(); // Mendapatkan Stage untuk window saat ini
    stage.setScene(scene);    

    }

    @FXML
    void goToTabTambahTugas(ActionEvent event) throws IOException {
    FXMLLoader loader = new FXMLLoader(getClass().getResource("tambahTugas.fxml"));
    Parent root = loader.load();
    Scene scene = new Scene(root);
    Stage stage = (Stage) hpTambahTugas.getScene().getWindow(); // Mendapatkan Stage untuk window saat ini
    stage.setScene(scene);
        
 

    }
    
        public void showDaftarTugas(){
        ObservableList<Tugas> list = getIdTugas();
        
        klmIdTugas.setCellValueFactory(new PropertyValueFactory<>("idTugas"));
        klmAnggota.setCellValueFactory(new PropertyValueFactory<>("anggota"));
        klmDeskripsiTugas.setCellValueFactory(new PropertyValueFactory<>("deskripsiTugas"));
        klmWaktuMulai.setCellValueFactory(new PropertyValueFactory<>("waktuMulai"));
        klmWaktuSelesai.setCellValueFactory(new PropertyValueFactory<>("waktuSelesai"));
        klmStatusTugas.setCellValueFactory(new PropertyValueFactory<>("status"));
        tblTugas.setItems(list);
    }
        
        
        
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       showDaftarTugas();
       
       tblTugas.setRowFactory(tv -> {
        return new TableRow<Tugas>() {
            @Override
            protected void updateItem(Tugas item, boolean empty) {
                super.updateItem(item, empty);

                // Set warna baris berdasarkan status tugas
                if (item == null || empty) {
                    setStyle("");
                } else {
                    if ("Selesai".equals(item.getStatus().getJenisStatus())) {
                        setStyle("-fx-background-color: #b9ceac;");
                    
                    } else {
                        setStyle(""); // Atur style kosong jika tidak Selesai atau Ditunda
                    }
                }
            }
        };
    });
    }    
    
}
