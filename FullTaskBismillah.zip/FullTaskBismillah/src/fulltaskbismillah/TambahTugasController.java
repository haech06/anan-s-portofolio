/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package fulltaskbismillah;

import db.dbHelper;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author acer
 */
public class TambahTugasController implements Initializable {

    

    @FXML
    private Button btnTambahData;

    @FXML
    private TextField fldDeskripsiTugas;

    @FXML
    private TextField fldIdAngggota;

    @FXML
    private TextField fldIdTugas;

    @FXML
    private TextField flsIdStatus;

    @FXML
    private DatePicker fldWaktuMulai;

    @FXML
    private DatePicker fldWaktuSelesai;

    @FXML
    private Hyperlink hpDaftarTugas;

    @FXML
    private Hyperlink hpDashboard;

    @FXML
    void dataBertambah(ActionEvent event) {
    if(event.getSource() == btnTambahData){
        tambahTugas();
        showInfoDialog("Berhasil menambahkan data");

    }    
    }

    @FXML
    void goToTabDaftarTugas(ActionEvent event) throws IOException {
    FXMLLoader loader = new FXMLLoader(getClass().getResource("tugas.fxml"));
    Parent root = loader.load();
    Scene scene = new Scene(root);
    Stage stage = (Stage) hpDaftarTugas.getScene().getWindow(); // Mendapatkan Stage untuk window saat ini
    stage.setScene(scene);    

    }

    @FXML
    void goToTabMenuUtama(ActionEvent event) throws IOException {
    FXMLLoader loader = new FXMLLoader(getClass().getResource("menuUtama.fxml"));
    Parent root = loader.load();
    Scene scene = new Scene(root);
    Stage stage = (Stage) hpDashboard.getScene().getWindow(); // Mendapatkan Stage untuk window saat ini
    stage.setScene(scene);    

    }
    
     private void update(String query){
        Connection conn = dbHelper.getConnection();
        Statement st;
        ResultSet rs;
        
        try{
            st = conn.createStatement();
            st.executeUpdate(query);
        } catch(SQLException ex){
            ex.printStackTrace();
        }
    }
    
  
    
    private void tambahTugas() {
    try {
        Connection conn = dbHelper.getConnection();
        String query = "INSERT INTO tugas (idTugas, idAnggotaTim,deskripsiTugas, waktuMulai, waktuSelesai, idStatus) VALUES (?, ?, ?, ?, ?, ?)";
        java.sql.PreparedStatement pst = conn.prepareStatement(query);
        
        pst.setInt(1, Integer.parseInt(fldIdTugas.getText()));
        pst.setInt(2, Integer.parseInt(fldIdAngggota.getText()));
        pst.setString(3, fldDeskripsiTugas.getText());
        pst.setDate(4, java.sql.Date.valueOf(fldWaktuMulai.getValue()));
        pst.setDate(5, java.sql.Date.valueOf(fldWaktuSelesai.getValue()));
        pst.setInt(6, Integer.parseInt(flsIdStatus.getText()));
        
        pst.executeUpdate();

        pst.close();
        conn.close();
        
        
    }
    catch (SQLException ex) {
        ex.printStackTrace();
    }

    }
   
      private void showInfoDialog(String content) {
      Alert alert = new Alert(Alert.AlertType.INFORMATION);
      alert.setHeaderText("BERHASIL");
      alert.setContentText("Berhasil menambahkan data");
      alert.showAndWait();

      }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        fldWaktuMulai.setValue(LocalDate.now());
        fldWaktuSelesai.setValue(LocalDate.now());
        // TODO
    }    
    
}
