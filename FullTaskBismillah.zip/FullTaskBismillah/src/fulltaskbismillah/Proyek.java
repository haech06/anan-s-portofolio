/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fulltaskbismillah;

import java.time.LocalDate;

/**
 *
 * @author acer
 */

public class Proyek{
    private int idProyek;
    private String namaProyek;
    private String tujuanProyek;
    private LocalDate tenggatWaktu;
    private double anggaran;
    private Status status;
    private Jadwal jadwal;
    

//    public Proyek(int idProyek) {
//        this.idProyek = idProyek;
//    }

    public Proyek(int idProyek) {
        this.idProyek = idProyek;
    }
    

    public Proyek(Jadwal jadwal) {
        this.jadwal = jadwal;
    }
    

    public Proyek(Status status) {
        this.status = status;
    }

    
    public Proyek(String namaProyek) {
        this.namaProyek = namaProyek;
    }
    

    public Proyek(int idProyek, String namaProyek, String tujuanProyek, LocalDate tenggatWaktu, double anggaran, Status status) {
        this.idProyek = idProyek;
        this.namaProyek = namaProyek;
        this.tujuanProyek = tujuanProyek;
        this.tenggatWaktu = tenggatWaktu;
        this.anggaran = anggaran;
        this.status = status;
        
    }

    public void setJadwal(Jadwal jadwal) {
        this.jadwal = jadwal;
    }
    

    public void setIdProyek(int idProyek) {
        this.idProyek = idProyek;
    }

    public void setNamaProyek(String namaProyek) {
        this.namaProyek = namaProyek;
    }

    public void setTujuanProyek(String tujuanProyek) {
        this.tujuanProyek = tujuanProyek;
    }

    public void setTenggatWaktu(LocalDate tenggatWaktu) {
        this.tenggatWaktu = tenggatWaktu;
    }

    public void setAnggaran(double anggaran) {
        this.anggaran = anggaran;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public Jadwal getJadwal() {
        return jadwal;
    }
    
    public int getIdProyek() {
        return idProyek;
    }

    public String getNamaProyek() {
        return namaProyek;
    }

    public String getTujuanProyek() {
        return tujuanProyek;
    }

    public LocalDate getTenggatWaktu() {
        return tenggatWaktu;
    }

    public double getAnggaran() {
        return anggaran;
    }

    public Status getStatus() {
        return status;
    }

  
   public String toString() {
        if (idProyek != 0) {
            return "" + idProyek;
        } else {
            return "" + namaProyek;
        }
    }

}
    
  
    
  
