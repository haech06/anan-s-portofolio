/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package fulltaskbismillah;
import com.mycompany.fulltaskbismillah.AnggotaTim;
import java.util.List;

/**
 *
 * @author acer
 */
public class Tim{
    private int idTim;
    private String namaTim;
    private String deskripsiTim;
    private List<AnggotaTim> anggotaTim;
    private Proyek proyek;
    
        
    public Tim(int idTim, String namaTim, String deskripsiTim, Proyek proyek) {
        this.idTim = idTim;
        this.namaTim = namaTim;
        this.deskripsiTim = deskripsiTim;
        //this.anggotaTim = anggotaTim;
        this.proyek = proyek;
        
    }

    public Tim(Proyek proyek) {
        this.proyek = proyek;
    }

    public Tim(int idTim) {
        this.idTim = idTim;
    }
    
    
    

    public Tim(int idTim, String namaTim, List<AnggotaTim> anggotaTim, Proyek proyek) {
        this.idTim = idTim;
        this.namaTim = namaTim;
        this.anggotaTim = anggotaTim;
        this.proyek = proyek;
        
    }

    public Tim(String deskripsiTim) {
        this.deskripsiTim = deskripsiTim;
    }
    
    

    public void setProyek(Proyek proyek) {
        this.proyek = proyek;
    }

    public void setIdTim(int idTim) {
        this.idTim = idTim;
    }

    public void setNamaTim(String namaTim) {
        this.namaTim = namaTim;
    }

    public void setAnggotaTim(List<AnggotaTim> anggotaTim) {
        this.anggotaTim = anggotaTim;
    }

    public int getIdTim() {
        return idTim;
    }

    public String getNamaTim() {
        return namaTim;
    }

    public Proyek getProyek() {
        return proyek;
    }

    public String getDeskripsiTim() {
        return deskripsiTim;
    }
    
   
    public List<AnggotaTim> getAnggotaTim() {
        return anggotaTim;
    }
    
    public void addAnggotaTim(){
        
    }
    
    public void removeAnggotaTim(){
        
    }
    
    public String toString(){
		return "" + idTim;
    
}
}
