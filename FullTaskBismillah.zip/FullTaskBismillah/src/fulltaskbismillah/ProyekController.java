/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package fulltaskbismillah;

import com.mycompany.fulltaskbismillah.AnggotaTim;
import db.dbHelper;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author acer
 */
public class ProyekController implements Initializable {
    
     @FXML
    private Button btnSearch;

    @FXML
    private Hyperlink hpDashboard;

    
    @FXML
    private Hyperlink hpTambahProyek;

    @FXML
    private TableColumn<Proyek, Double> klmAnggaran;

    @FXML
    private TableColumn<Proyek, Integer> klmIDp;

    @FXML
    private TableColumn<Proyek, String> klmNamaProyek;

    @FXML
    private TableColumn<Proyek, Status> klmStatus;

    @FXML
    private TableColumn<Proyek, LocalDate> klmTenggat;

    @FXML
    private TableColumn<Proyek, String> klmTujuan;
    
    @FXML
    private TableView<Proyek> tblProyek;
    
    
   

    @FXML
    void goToTabMenuUtama(ActionEvent event) throws IOException {
    
    FXMLLoader loader = new FXMLLoader(getClass().getResource("menuUtama.fxml"));
    Parent root = loader.load();
    Scene scene = new Scene(root);
    Stage stage = (Stage) hpDashboard.getScene().getWindow(); // Mendapatkan Stage untuk window saat ini
    stage.setScene(scene);

    }

    @FXML
    void goToTabTambahProyek(ActionEvent event) throws IOException {
  
    FXMLLoader loader = new FXMLLoader(getClass().getResource("tambahProyek.fxml"));
    Parent root = loader.load();
    Scene scene = new Scene(root);
    Stage stage = (Stage) hpTambahProyek.getScene().getWindow(); // Mendapatkan Stage untuk window saat ini
    stage.setScene(scene);

    }
    
     public ObservableList<Proyek> getIdProyek(){
        ObservableList<Proyek> proyek = FXCollections.observableArrayList();
        Connection connection = dbHelper.getConnection();
        String query = "SELECT p.IDProyek, p.namaProyek, p.tujuanProyek, "
                + "p.tenggatWaktu, p.Anggaran, s.jenisStatus"
                + " FROM proyek p JOIN status s ON p.idStatus = s.idStatus";

        Statement st;
        ResultSet rs;
        
        try{
            if (connection != null){
            st = connection.createStatement();
            rs = st.executeQuery(query);
            Proyek temp;
            while (rs.next()){
            temp = new Proyek(
            rs.getInt("IDProyek"),
            rs.getString("namaProyek"),
            rs.getString("tujuanProyek"),
            rs.getDate("tenggatWaktu").toLocalDate(),
            rs.getDouble("Anggaran"),
            new Status(rs.getString("jenisStatus"))
        );
            proyek.add(temp);

  
            }
            } else {
                System.out.println("Koneksi ke database gagal.");
            }
        } catch (SQLException ex){
            ex.printStackTrace();
        }
        
        return proyek;
        
    }
    
    public void showDaftarProyek(){
        ObservableList<Proyek> list = getIdProyek();
        
        klmIDp.setCellValueFactory(new PropertyValueFactory<>("idProyek"));
        klmNamaProyek.setCellValueFactory(new PropertyValueFactory<>("namaProyek"));
        klmTujuan.setCellValueFactory(new PropertyValueFactory<>("tujuanProyek"));
        klmTenggat.setCellValueFactory(new PropertyValueFactory<>("tenggatWaktu"));
        klmAnggaran.setCellValueFactory(new PropertyValueFactory<>("anggaran"));
        klmStatus.setCellValueFactory(new PropertyValueFactory<>("status"));
        tblProyek.setItems(list);
    }


    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        showDaftarProyek();
    }    
    
}
