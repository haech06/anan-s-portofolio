/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.fulltaskbismillah;

import fulltaskbismillah.Status;
import fulltaskbismillah.Tim;
import fulltaskbismillah.Tugas;

/**
 *
 * @author acer
 */
public class AnggotaTim {
    private int idAnggotaTim;
    private String namaAnggota;
    private String peranAnggota;
    private String kontakAnggota;
    private String hapusAnggota;
    private String username;
    private String password;
    private Tim tim;
    private Tugas tugas;
    private Status status;

  
    public AnggotaTim(String namaAnggota) {
        this.namaAnggota = namaAnggota;
    }

    public AnggotaTim(Tugas tugas) {
        this.tugas = tugas;
    }

    public AnggotaTim(Status status) {
        this.status = status;
    }


   
    public AnggotaTim(Tim tim) {
        this.tim = tim;
    }
    
    public AnggotaTim(Tim tim, int idAnggotaTim, String namaAnggota, String peranAnggota, String kontakAnggota) {
        this.tim = tim;
        this.idAnggotaTim = idAnggotaTim;
        this.namaAnggota = namaAnggota;
        this.peranAnggota = peranAnggota;
        this.kontakAnggota = kontakAnggota;
        this.hapusAnggota = hapusAnggota;
    }

    public AnggotaTim(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public AnggotaTim(String namaAnggota, String username, String password) {
        this.namaAnggota = namaAnggota;
        this.username = username;
        this.password = password;
    }

    public void setTugas(Tugas tugas) {
        this.tugas = tugas;
    }

    public void setStatus(Status status) {
        this.status = status;
    }
    
    

    public void setTim(Tim tim) {
        this.tim = tim;
    }

    public Tim getTim() {
        return tim;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public Tugas getTugas() {
        return tugas;
    }

    public Status getStatus() {
        return status;
    }

    public void setIdAnggotaTim(int idAnggotaTim) {
        this.idAnggotaTim = idAnggotaTim;
    }

    public void setNamaAnggota(String namaAnggota) {
        this.namaAnggota = namaAnggota;
    }

    public void setPeranAnggota(String peranAnggota) {
        this.peranAnggota = peranAnggota;
    }

    public void setKontakAnggota(String kontakAnggota) {
        this.kontakAnggota = kontakAnggota;
    }

    public int getIdAnggotaTim() {
        return idAnggotaTim;
    }

    public String getNamaAnggota() {
        return namaAnggota;
    }

    public String getPeranAnggota() {
        return peranAnggota;
    }

    public String getKontakAnggota() {
        return kontakAnggota;
    }
    
    public void getProyek(){
        
    }
    
    public String toString(){
		return "" + namaAnggota;
    }
   
    
}
